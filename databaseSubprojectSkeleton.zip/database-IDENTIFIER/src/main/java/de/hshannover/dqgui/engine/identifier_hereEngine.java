package de.hshannover.dqgui.engine;

import de.hshannover.dqgui.execution.database.api.DatabaseConnection;
import de.hshannover.dqgui.execution.database.api.DatabaseEngine;
import de.hshannover.dqgui.execution.database.api.DatabaseFetcher;
import de.hshannover.dqgui.execution.database.api.DatabaseTests.DatabaseTestResult;
import de.hshannover.dqgui.execution.database.api.Repository;

public class identifier_hereEngine extends DatabaseEngine {

    protected identifier_hereEngine() throws Exception {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    protected void loadDatabaseDriver() throws Exception {
        // TODO Auto-generated method stub
        
    }

    @Override
    public DatabaseFetcher createFetcher(DatabaseConnection connection) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String name() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public DatabaseTestResult test(DatabaseConnection connection) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public boolean isRelational() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean allowUseForRepository() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean allowUseForIqm4hd() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean supportsJdbc() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public String createDataSourceUrl(DatabaseConnection connection) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    protected Repository<?> createRepositoryForConnection(DatabaseConnection connection) {
        // TODO Auto-generated method stub
        return null;
    }

}
